package com.example.studentapp.service;

import com.example.studentapp.model.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentService {
    private final List<Student> students = new ArrayList<>();

    public boolean addStudent(Student student) {
        // Check for duplicate ID
        for (Student s : students) {
            if (s.getId() == student.getId()) {
                return false;
            }
        }
        students.add(student);
        return true;
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }

    public Student getStudentById(int id) {
        for (Student s : students) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }

    public boolean updateStudent(int id, String name, int age, String email) {
        Student s = getStudentById(id);
        if (s != null) {
            s.setName(name);
            s.setAge(age);
            s.setEmail(email);
            return true;
        }
        return false;
    }

    public boolean deleteStudent(int id) {
        Student s = getStudentById(id);
        if (s != null) {
            students.remove(s);
            return true;
        }
        return false;
    }
} 