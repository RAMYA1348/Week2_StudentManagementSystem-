package com.example.studentapp;

import com.example.studentapp.model.Student;
import com.example.studentapp.service.StudentService;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentService service = new StudentService();
        boolean running = true;

        while (running) {
            System.out.println("\n--- Student Management System ---");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = -1;
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
            } else {
                scanner.next(); // consume invalid input
            }

            switch (choice) {
                case 1:
                    // Add Student
                    System.out.print("Enter ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    if (name.isEmpty() || email.isEmpty() || age <= 0) {
                        System.out.println("Invalid input. Please try again.");
                        break;
                    }
                    Student student = new Student(id, name, age, email);
                    if (service.addStudent(student)) {
                        System.out.println("Student added successfully.");
                    } else {
                        System.out.println("Student with this ID already exists.");
                    }
                    break;
                case 2:
                    // View All Students
                    System.out.println("\nList of Students:");
                    for (Student s : service.getAllStudents()) {
                        System.out.println(s);
                    }
                    break;
                case 3:
                    // Update Student
                    System.out.print("Enter ID of student to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();
                    Student toUpdate = service.getStudentById(updateId);
                    if (toUpdate == null) {
                        System.out.println("Student not found.");
                        break;
                    }
                    System.out.print("Enter new Name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new Age: ");
                    int newAge = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new Email: ");
                    String newEmail = scanner.nextLine();
                    if (newName.isEmpty() || newEmail.isEmpty() || newAge <= 0) {
                        System.out.println("Invalid input. Please try again.");
                        break;
                    }
                    if (service.updateStudent(updateId, newName, newAge, newEmail)) {
                        System.out.println("Student updated successfully.");
                    } else {
                        System.out.println("Update failed.");
                    }
                    break;
                case 4:
                    // Delete Student
                    System.out.print("Enter ID of student to delete: ");
                    int deleteId = scanner.nextInt();
                    scanner.nextLine();
                    if (service.deleteStudent(deleteId)) {
                        System.out.println("Student deleted successfully.");
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;
                case 5:
                    running = false;
                    System.out.println("Exiting program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
        scanner.close();
    }
} 